package proyectotercerparcial;

import javax.swing.*;

public class Menu extends JFrame {
    public Menu(int idUsuario) {
        setTitle("Menu Principal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
    }
}